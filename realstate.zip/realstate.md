```python
import pandas as pd

# Replace with your exact file name
df = pd.read_csv('Real state.csv')

# Show the first 5 rows to verify
df.head()

```

    C:\Users\BARKAT-ALI\AppData\Local\Temp\ipykernel_13960\4167167883.py:4: DtypeWarning: Columns (8,9,10,11,12) have mixed types. Specify dtype option on import or set low_memory=False.
      df = pd.read_csv('Real state.csv')
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Serial Number</th>
      <th>List Year</th>
      <th>Date Recorded</th>
      <th>Town</th>
      <th>Address</th>
      <th>Assessed Value</th>
      <th>Sale Amount</th>
      <th>Sales Ratio</th>
      <th>Property Type</th>
      <th>Residential Type</th>
      <th>Non Use Code</th>
      <th>Assessor Remarks</th>
      <th>OPM remarks</th>
      <th>Location</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2020177</td>
      <td>2020</td>
      <td>04/14/2021</td>
      <td>Ansonia</td>
      <td>323 BEAVER ST</td>
      <td>133000.0</td>
      <td>248400.0</td>
      <td>0.5354</td>
      <td>Residential</td>
      <td>Single Family</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>POINT (-73.06822 41.35014)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020225</td>
      <td>2020</td>
      <td>05/26/2021</td>
      <td>Ansonia</td>
      <td>152 JACKSON ST</td>
      <td>110500.0</td>
      <td>239900.0</td>
      <td>0.4606</td>
      <td>Residential</td>
      <td>Three Family</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020348</td>
      <td>2020</td>
      <td>09/13/2021</td>
      <td>Ansonia</td>
      <td>230 WAKELEE AVE</td>
      <td>150500.0</td>
      <td>325000.0</td>
      <td>0.4630</td>
      <td>Commercial</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020090</td>
      <td>2020</td>
      <td>12/14/2020</td>
      <td>Ansonia</td>
      <td>57 PLATT ST</td>
      <td>127400.0</td>
      <td>202500.0</td>
      <td>0.6291</td>
      <td>Residential</td>
      <td>Two Family</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>210288</td>
      <td>2021</td>
      <td>06/20/2022</td>
      <td>Avon</td>
      <td>12 BYRON DRIVE</td>
      <td>179990.0</td>
      <td>362500.0</td>
      <td>0.4965</td>
      <td>Residential</td>
      <td>Condo</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>POINT (-72.879115982 41.773452988)</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
df.describe()
df.columns

```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1097629 entries, 0 to 1097628
    Data columns (total 14 columns):
     #   Column            Non-Null Count    Dtype  
    ---  ------            --------------    -----  
     0   Serial Number     1097629 non-null  int64  
     1   List Year         1097629 non-null  int64  
     2   Date Recorded     1097627 non-null  object 
     3   Town              1097629 non-null  object 
     4   Address           1097578 non-null  object 
     5   Assessed Value    1097629 non-null  float64
     6   Sale Amount       1097629 non-null  float64
     7   Sales Ratio       1097629 non-null  float64
     8   Property Type     715183 non-null   object 
     9   Residential Type  699240 non-null   object 
     10  Non Use Code      313451 non-null   object 
     11  Assessor Remarks  171228 non-null   object 
     12  OPM remarks       13031 non-null    object 
     13  Location          298111 non-null   object 
    dtypes: float64(3), int64(2), object(9)
    memory usage: 117.2+ MB
    




    Index(['Serial Number', 'List Year', 'Date Recorded', 'Town', 'Address',
           'Assessed Value', 'Sale Amount', 'Sales Ratio', 'Property Type',
           'Residential Type', 'Non Use Code', 'Assessor Remarks', 'OPM remarks',
           'Location'],
          dtype='object')




```python
import seaborn as sns
import matplotlib.pyplot as plt

sns.histplot(df['Assessed Value'], bins=50, kde=True)
plt.title('Distribution of Assessed Property Values')
plt.xlabel('Assessed Value')
plt.ylabel('Number of Properties')
plt.show()

```


    
![png](output_2_0.png)
    



```python
plt.figure(figsize=(10, 6))
sns.boxplot(x='List Year', y='Sale Amount', data=df)
plt.yscale('log')  # If values are large
plt.title('Sale Amount Distribution by List Year')
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_3_0.png)
    



```python
top_towns = df['Town'].value_counts().head(10)

plt.figure(figsize=(10,6))
sns.barplot(x=top_towns.index, y=top_towns.values)
plt.title('Top 10 Most Common Towns in Dataset')
plt.ylabel('Number of Properties')
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_4_0.png)
    



```python
plt.figure(figsize=(10,6))
sns.barplot(x='Property Type', y='Sales Ratio', data=df)
plt.title('Average Sales Ratio by Property Type')
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_5_0.png)
    



```python
plt.figure(figsize=(8,6))
sns.heatmap(df[['Assessed Value', 'Sale Amount', 'Sales Ratio']].corr(), annot=True, cmap='coolwarm')
plt.title('Correlation Between Numeric Features')
plt.show()

```


    
![png](output_6_0.png)
    



```python
sns.scatterplot(x='Assessed Value', y='Sale Amount', data=df, alpha=0.5)
plt.title('Assessed Value vs Sale Amount')
plt.xlabel('Assessed Value')
plt.ylabel('Sale Amount')
plt.show()

```


    
![png](output_7_0.png)
    



```python
df_clean = df.dropna(subset=['Assessed Value', 'Sale Amount', 'List Year', 'Property Type'])

```


```python

```
